# Capricorn AI — prototipo Android

Aplicación Android nativa (Kotlin + Jetpack Compose) con estética cyberpunk y el retrato de referencia incluido como avatar.

## Incluye en este prototipo
- Pantalla principal con avatar Capricorn.
- Activación/desactivación manual de una burbuja flotante pequeña sobre otras aplicaciones (permiso «Mostrar sobre otras apps»).
- Burbuja arrastrable; al tocarla vuelve a abrir la app.
- Nombre principal y alias editables (por ejemplo: Capricorn, Capri, Cap).
- Idioma seleccionable para voz y solicitudes: español, inglés, portugués, francés, alemán, italiano, japonés, coreano y chino (depende de voces instaladas en Android).
- Entrada por reconocimiento de voz del sistema y salida mediante Android Text-to-Speech.
- Memoria local sencilla de las últimas interacciones.
- Conexión opcional a una API compatible con OpenAI Chat Completions.

## Requisitos
- Android Studio reciente (AGP 8.7.3), JDK 17 y Android SDK 35.
- Android 8.0 o superior.

## Abrir y ejecutar
1. Descomprime el ZIP.
2. Abre la carpeta `CapricornAI` desde Android Studio.
3. Espera la sincronización de Gradle y ejecuta en tu teléfono.
4. En la app, pulsa **Activar burbuja** y concede «Mostrar sobre otras apps» en Ajustes de Android. Vuelve a Capricorn AI y pulsa Activar de nuevo.
5. Para respuestas de IA reales, abre Ajustes y configura endpoint, nombre del modelo y clave API de un proveedor compatible.

## Límites importantes del prototipo
- Este proyecto es código fuente; no incluye un APK compilado ni una clave de IA.
- El botón de micrófono usa el reconocedor de voz instalado en Android. No implementa todavía una palabra de activación permanente («Capricorn»/«Capri») mientras otras apps están abiertas.
- La burbuja es un avatar flotante que abre la aplicación; no ejecuta por sí sola acciones arbitrarias del sistema. Abrir apps, activar Bluetooth, leer notificaciones y otras acciones requieren módulos Android específicos, permisos y, en algunos casos, confirmación del usuario.
- La memoria se guarda localmente en preferencias de la app. No es una memoria cifrada ni sincronizada.
- La clave API se guarda localmente en preferencias para facilitar pruebas. Para distribuir la app debe migrarse a almacenamiento seguro y, preferiblemente, a un servidor intermediario; nunca publiques una clave dentro de un APK.
- La disponibilidad y calidad de TTS/STT multilingüe depende del motor de voz y los paquetes instalados en el dispositivo.

## Próximas etapas recomendadas
1. Servicio de palabra de activación de bajo consumo con controles visibles y consentimiento explícito.
2. Acciones Android seguras mediante intents y accesibilidad solo donde sea necesario.
3. Almacenamiento de memoria con Room y cifrado.
4. Backend seguro para el modelo de IA y configuración de voces/persona.
5. Pruebas de compatibilidad en el modelo exacto de teléfono.

## Generar el APK automáticamente (GitHub Actions)

Este proyecto incluye `.github/workflows/build-apk.yml`.

1. Sube el contenido de esta carpeta a un repositorio de GitHub (rama `main` o `master`).
2. Abre la pestaña **Actions** del repositorio.
3. Selecciona **Build Capricorn AI APK** y pulsa **Run workflow** (también se ejecuta al hacer push a `main`/`master`).
4. Cuando termine, abre la ejecución y descarga el artefacto **CapricornAI-debug-apk**.
5. Dentro del ZIP del artefacto encontrarás `app-debug.apk`. Descárgalo en Android y permite la instalación desde esa fuente si el sistema lo solicita.

El workflow genera un APK de depuración (`debug`), no un APK firmado para publicar en Google Play. La compilación en GitHub Actions debe completarse correctamente antes de instalarlo. No se ha compilado ni probado un APK en este entorno.


## Compilar el APK automáticamente

1. Crea un repositorio nuevo en GitHub.
2. Sube **todo el contenido** de esta carpeta, incluida `.github`.
3. Abre **Actions** → **Build Capricorn AI APK** → **Run workflow**.
4. Cuando termine correctamente, abre la ejecución y descarga `CapricornAI-debug-apk`.
5. Descomprime el artefacto y abre `app-debug.apk` en tu Android para instalarlo.

También se compila automáticamente al subir cambios a `main` o `master`.

**Importante:** este paquete contiene el proyecto Android y el flujo automatizado de compilación, pero no un APK ya compilado. El entorno actual no tiene Android SDK ni Gradle instalados y no puede ejecutar GitHub Actions ni subir archivos a tu cuenta de GitHub.
