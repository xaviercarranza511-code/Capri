package com.capricorn.ai

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import android.widget.Toast
import android.view.MotionEvent
import android.view.WindowManager.LayoutParams

class FloatingCompanionService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val image = ImageView(this).apply {
            setImageResource(com.capricorn.ai.R.drawable.capricorn_avatar)
            scaleType = ImageView.ScaleType.CENTER_CROP
            contentDescription = "Capricorn AI: toca para abrir"
            setBackgroundColor(0xFF090510.toInt())
            setOnClickListener { startActivity(Intent(this@FloatingCompanionService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)) }
        }
        val type = if (android.os.Build.VERSION.SDK_INT >= 26) LayoutParams.TYPE_APPLICATION_OVERLAY else LayoutParams.TYPE_PHONE
        val params = LayoutParams(dp(62), dp(62), type, LayoutParams.FLAG_NOT_FOCUSABLE or LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END; x = dp(12); y = dp(180)
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        image.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; true }
                MotionEvent.ACTION_MOVE -> { params.x = (startX - (event.rawX-downX).toInt()).coerceAtLeast(0); params.y = (startY + (event.rawY-downY).toInt()).coerceAtLeast(0); wm.updateViewLayout(image, params); true }
                MotionEvent.ACTION_UP -> { if (kotlin.math.abs(event.rawX-downX) < 8 && kotlin.math.abs(event.rawY-downY) < 8) image.performClick(); true }
                else -> false
            }
        }
        bubble = image
        try { wm.addView(image, params) } catch (_: Exception) { Toast.makeText(this, "Concede permiso para mostrarse sobre otras apps", Toast.LENGTH_LONG).show(); stopSelf() }
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() { bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
}
