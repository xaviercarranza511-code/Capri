package com.capricorn.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject

private val Neon = Color(0xFFFF1478)
private val Green = Color(0xFF00E58A)
private val Night = Color(0xFF090510)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) {}
        setContent { CapricornScreen(onSpeak = { speak(it) }) }
    }
    private fun speak(text: String) {
        val tag = Prefs.language(this)
        val locale = Locale.forLanguageTag(tag)
        tts?.language = locale
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "capricorn_reply")
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapricornScreen(onSpeak: (String) -> Unit) {
    val context = LocalContext.current
    val activity = context as Activity
    val scope = rememberCoroutineScope()
    var enabled by remember { mutableStateOf(Prefs.enabled(context)) }
    var name by remember { mutableStateOf(Prefs.get(context, "name", "Capricorn")) }
    var aliasText by remember { mutableStateOf(Prefs.aliases(context).joinToString(", ")) }
    var language by remember { mutableStateOf(Prefs.language(context)) }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var messages by remember { mutableStateOf(listOf("Capricorn: Sistema en línea. ¿Qué necesitas, usuario?")) }
    var apiKey by remember { mutableStateOf(Prefs.get(context, "api_key")) }
    var endpoint by remember { mutableStateOf(Prefs.get(context, "endpoint", "https://api.openai.com/v1/chat/completions")) }
    var model by remember { mutableStateOf(Prefs.get(context, "model", "gpt-4o-mini")) }
    var showSettings by remember { mutableStateOf(false) }
    var micError by remember { mutableStateOf("") }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            input = spoken
        } else micError = "No se reconoció voz. Puedes escribir o volver a intentar."
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    MaterialTheme(colorScheme = darkColorScheme(primary = Neon, secondary = Green, background = Night, surface = Color(0xFF160D20))) {
        Scaffold(containerColor = Night, topBar = {
            TopAppBar(title = { Column { Text(name.uppercase(), color = Neon, fontWeight = FontWeight.Black); Text("TU IA PERSONAL • MULTILINGÜE", color = Green, style = MaterialTheme.typography.labelSmall) } }, actions = {
                IconButton(onClick = { showSettings = !showSettings }) { Text("⚙", color = Green) }
            }, colors = TopAppBarDefaults.topAppBarColors(containerColor = Night))
        }) { padding ->
            LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFF1A0B20)), border = androidx.compose.foundation.BorderStroke(1.dp, Neon)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(painterResource(R.drawable.capricorn_avatar), null, Modifier.fillMaxWidth().height(250.dp), contentScale = ContentScale.Crop)
                            Spacer(Modifier.height(8.dp))
                            Text(if (enabled) "● EN LÍNEA" else "○ DESACTIVADA", color = if (enabled) Green else Color.LightGray, fontWeight = FontWeight.Bold)
                            Text("Fría • Inteligente • Calculadora", color = Color.White)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = {
                                    if (!enabled) {
                                        if (!Settings.canDrawOverlays(context)) activity.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                        else { Prefs.setEnabled(context, true); enabled = true; context.startService(Intent(context, FloatingCompanionService::class.java)) }
                                    } else { Prefs.setEnabled(context, false); enabled = false; context.stopService(Intent(context, FloatingCompanionService::class.java)) }
                                }, colors = ButtonDefaults.buttonColors(containerColor = if (enabled) Color(0xFF5C183A) else Neon)) {
                                    Icon(Icons.Default.PowerSettingsNew, null); Spacer(Modifier.width(6.dp)); Text(if (enabled) "Desactivar" else "Activar burbuja")
                                }
                            }
                            Text("Al activarla aparece como avatar flotante pequeño sobre otras aplicaciones. Tócalo para volver aquí.", color = Color.LightGray, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                if (showSettings) item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF160D20)), border = androidx.compose.foundation.BorderStroke(1.dp, Green)) {
                        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("IDENTIDAD Y AJUSTES", color = Green, fontWeight = FontWeight.Bold)
                            OutlinedTextField(name, { name = it; Prefs.put(context,"name",it) }, label = { Text("Nombre principal") }, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(aliasText, { aliasText = it; Prefs.saveAliases(context,it.split(",").map { alias -> alias.trim() }.filter { alias -> alias.isNotBlank() }) }, label = { Text("Alias separados por coma (Capri, Cap)") }, modifier = Modifier.fillMaxWidth())
                            var expanded by remember { mutableStateOf(false) }
                            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                                OutlinedTextField(language, {}, readOnly = true, label = { Text("Idioma de voz") }, trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) }, modifier = Modifier.menuAnchor().fillMaxWidth())
                                ExposedDropdownMenu(expanded, { expanded = false }) {
                                    listOf("es-EC" to "Español", "en-US" to "English", "pt-BR" to "Português", "fr-FR" to "Français", "de-DE" to "Deutsch", "it-IT" to "Italiano", "ja-JP" to "日本語", "ko-KR" to "한국어", "zh-CN" to "中文").forEach { (tag,label) -> DropdownMenuItem(text={Text(label)}, onClick={ language=tag; Prefs.put(context,"language",tag); expanded=false }) }
                                }
                            }
                            OutlinedTextField(endpoint, { endpoint=it; Prefs.put(context,"endpoint",it) }, label={Text("API compatible con Chat Completions")}, modifier=Modifier.fillMaxWidth())
                            OutlinedTextField(model, { model=it; Prefs.put(context,"model",it) }, label={Text("Modelo")}, modifier=Modifier.fillMaxWidth())
                            OutlinedTextField(apiKey, { apiKey=it; Prefs.put(context,"api_key",it) }, label={Text("Clave API (se guarda localmente)")}, modifier=Modifier.fillMaxWidth())
                            Text("La clave es opcional para probar el prototipo. Para respuestas inteligentes reales configura un proveedor compatible; no compartas el APK con tu clave dentro.", color=Color.LightGray, style=MaterialTheme.typography.bodySmall)
                        }
                    }
                }
                item { Text("CONVERSACIÓN", color = Green, fontWeight = FontWeight.Bold) }
                items(messages) { line -> Text(line, color = Color.White, modifier = Modifier.fillMaxWidth().background(Color(0xFF1A1020), RoundedCornerShape(12.dp)).padding(12.dp)) }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(input, { input=it }, modifier=Modifier.weight(1f), placeholder={Text("Habla con $name...")}, singleLine=true)
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE, language) }
                            try { speechLauncher.launch(intent) } catch (_: Exception) { micError = "No hay servicio de reconocimiento de voz disponible." }
                        }) { Icon(Icons.Default.Mic, contentDescription="Hablar", tint=Green) }
                        IconButton(enabled = input.isNotBlank() && !busy, onClick = {
                            val prompt=input.trim(); input=""; messages=messages+"Tú: $prompt"; Prefs.remember(context,"Usuario: $prompt"); busy=true
                            scope.launch {
                                val reply = askCapricorn(context, endpoint, model, apiKey, prompt)
                                messages=messages+"$name: $reply"; Prefs.remember(context,"$name: $reply"); onSpeak(reply); busy=false
                            }
                        }) { Icon(Icons.Default.Send, contentDescription="Enviar", tint=Neon) }
                    }
                    if (busy) LinearProgressIndicator(Modifier.fillMaxWidth(), color=Neon)
                    if (micError.isNotBlank()) Text(micError, color=Color.Yellow)
                }
                item { Text("Comandos de voz: ${Prefs.aliases(context).joinToString(" / ")} abre Instagram. La detección continua de palabra clave aún requiere un módulo de escucha en segundo plano; esta versión usa el botón de micrófono y la burbuja flotante.", color=Color.LightGray, style=MaterialTheme.typography.bodySmall) }
                item { Spacer(Modifier.height(24.dp)) }
            }
        }
    }
}

private suspend fun askCapricorn(context: android.content.Context, endpoint: String, model: String, key: String, prompt: String): String = withContext(Dispatchers.IO) {
    if (key.isBlank()) return@withContext "Puedo conversar y conservar esta sesión, pero falta configurar una clave API para activar el modelo de lenguaje. Entra en Ajustes y añade tu proveedor."
    try {
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply { requestMethod="POST"; connectTimeout=20000; readTimeout=30000; doOutput=true; setRequestProperty("Content-Type","application/json"); setRequestProperty("Authorization","Bearer $key") }
        val memory = Prefs.get(context,"memory","").takeLast(2500)
        val system = "Eres ${Prefs.get(context,"name","Capricorn")}, asistente personal cyberpunk. Personalidad: fría, inteligente, calculadora, leal y respetuosa. Responde en el idioma ${Prefs.language(context)}. Sé clara y natural. No afirmes controlar el teléfono si no se ha ejecutado una acción real. Memoria reciente: $memory"
        val body = JSONObject().put("model",model).put("messages",org.json.JSONArray().put(JSONObject().put("role","system").put("content",system)).put(JSONObject().put("role","user").put("content",prompt))).toString()
        conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val result = stream.bufferedReader().use { it.readText() }
        val json=JSONObject(result)
        if (conn.responseCode !in 200..299) "Error del proveedor (${conn.responseCode}): ${json.optString("error",result).take(300)}"
        else json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    } catch (e: Exception) { "No pude conectar con el servicio de IA: ${e.localizedMessage ?: "error de red"}. Revisa Internet, endpoint y clave API." }
}
