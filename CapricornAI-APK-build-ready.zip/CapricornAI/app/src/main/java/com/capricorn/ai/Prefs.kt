package com.capricorn.ai

import android.content.Context

object Prefs {
    private const val FILE = "capricorn_settings"
    private fun p(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun get(c: Context, key: String, fallback: String = "") = p(c).getString(key, fallback) ?: fallback
    fun put(c: Context, key: String, value: String) { p(c).edit().putString(key, value).apply() }
    fun enabled(c: Context) = p(c).getBoolean("enabled", false)
    fun setEnabled(c: Context, value: Boolean) { p(c).edit().putBoolean("enabled", value).apply() }
    fun aliases(c: Context): List<String> = get(c, "aliases", "Capricorn,Capri,Cap").split(",").map { it.trim() }.filter { it.isNotBlank() }
    fun saveAliases(c: Context, list: List<String>) = put(c, "aliases", list.joinToString(","))
    fun language(c: Context) = get(c, "language", "es-EC")
    fun remember(c: Context, line: String) {
        val old = get(c, "memory", "")
        put(c, "memory", (old + "\n" + line).takeLast(6000))
    }
}
